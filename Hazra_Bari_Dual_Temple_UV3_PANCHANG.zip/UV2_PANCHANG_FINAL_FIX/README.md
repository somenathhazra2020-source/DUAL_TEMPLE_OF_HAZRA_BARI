# UV2 Panchang Final Fix

Main file: uv2.py

This build removes the broken `_dt_datetime` fallback alias. Panchang uses the standard datetime import directly and remains usable when Swiss Ephemeris is unavailable.

Deploy both `uv2.py` and `requirements.txt` together.
