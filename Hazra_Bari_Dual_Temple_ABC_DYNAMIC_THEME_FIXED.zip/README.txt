HAZRA BARI DUAL TEMPLE - ABC.PY

Main Streamlit file: abc.py

Dynamic theme rules:
- Monday: Bright White
- Tuesday: Bright Pinkish Red
- Wednesday: Bright Green
- Thursday: Bright Yellow
- Friday: Bright Silver
- Saturday: Bright Blue
- Sunday: Bright Maroon
- Krishna Ashtami and Shukla Ashtami: Bright Red override
- Light phase: actual Durgapur sunrise until actual sunset
- Dark phase: after actual sunset until next sunrise
- Weekday theme boundary: actual moonrise
- IST / Durgapur astronomy
- Theme recalculates every 60 seconds while the app is open

Requirements include Swiss Ephemeris and Streamlit AutoRefresh.
