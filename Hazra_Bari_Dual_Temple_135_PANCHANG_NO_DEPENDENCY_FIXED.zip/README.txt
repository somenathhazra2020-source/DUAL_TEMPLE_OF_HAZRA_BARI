HAZRA BARI DUAL TEMPLE — 135.py PANCHANG DEPLOYMENT FIX

Main file: 135.py

IMPORTANT:
This build removes pysweph/ephem completely. It does NOT require a native
astronomy package, so it can run in Streamlit Community Cloud Python 3.14.

PANCHANG SOURCE:
The app reads live Durgapur Panchang data from the user-specified Drik Panchang
Durgapur reference page at runtime. Daily Panchang values are not hard-coded.

Reference:
https://www.drikpanchang.com/panchang/month-panchang.html?geoname-id=1272175

The app extracts current-day:
- Tithi
- Nakshatra
- Sunrise
- Sunset
- Moonrise
- Moonset
- Paksha
- Yoga
- Karana
- Weekday

The rest of the Hazra Bari Dual Temple features are retained.

requirements.txt intentionally contains only:
streamlit
streamlit-autorefresh

If the Panchang cannot be fetched, the app reports a network/source error
instead of a misleading missing-package error.
