HAZRA BARI DUAL TEMPLE — 8900.py

PANCHANG DEPLOYMENT REQUIREMENT
--------------------------------
This build does NOT attempt to pip-install packages at application runtime.
Streamlit Cloud must install dependencies before starting the app.

Required files:
  8900.py
  requirements.txt

requirements.txt includes:
  pysweph==2.10.3.6

IMPORTANT:
Deploy this app using Python 3.13. pysweph 2.10.3.6 provides Linux wheels for
CPython 3.13. If the existing Streamlit app is already deployed on Python 3.14,
Streamlit Community Cloud requires deleting that deployment and redeploying it
with Python 3.13 through Advanced settings.

Main file: 8900.py
Timezone: Asia/Kolkata (IST)
Location: Durgapur, West Bengal, India
Panchang: Swiss Ephemeris + Lahiri sidereal calculations
No daily Panchang values are hard-coded.
